package kr.co.salt.videodupecleaner;

public final class VideoSimilarityTest {
    public static void main(String[] args) {
        findsReencodedCopyWithSmallFrameChanges();
        rejectsDifferentVideoWithSameDuration();
        rejectsMatchingFramesWhenDurationDiffers();
        acceptsShortVideoDurationRounding();
        includesVideosInSelectedSubfolders();
        excludesSiblingFoldersWithSamePrefix();
        System.out.println("VideoSimilarityTest: PASS");
    }

    private static void findsReencodedCopyWithSmallFrameChanges() {
        long[] original = {0x0F0F0F0F0F0F0F0FL, 0x3333333333333333L, 0x5555555555555555L};
        long[] reencoded = {0x0F0F0F0F0F0F0F07L, 0x3333333333333331L, 0x5555555555555575L};
        expect(VideoSimilarity.isSimilar(60_000, original, 60_700, reencoded),
                "재인코딩으로 몇 비트가 달라진 같은 영상은 유사 중복이어야 함");
    }

    private static void rejectsDifferentVideoWithSameDuration() {
        long[] first = {0x0000000000000000L, 0x0000000000000000L, 0x0000000000000000L};
        long[] second = {0xFFFFFFFFFFFFFFFFL, 0xAAAAAAAAAAAAAAAAL, 0x5555555555555555L};
        expect(!VideoSimilarity.isSimilar(30_000, first, 30_100, second),
                "길이만 같은 다른 영상은 중복이면 안 됨");
    }

    private static void rejectsMatchingFramesWhenDurationDiffers() {
        long[] frames = {1L, 2L, 3L};
        expect(!VideoSimilarity.isSimilar(30_000, frames, 38_000, frames),
                "장면이 같아도 영상 길이가 크게 다르면 중복이면 안 됨");
    }

    private static void acceptsShortVideoDurationRounding() {
        long[] frames = {1L, 2L, 3L};
        expect(VideoSimilarity.isSimilar(4_000, frames, 4_900, frames),
                "짧은 영상의 1초 이내 길이 차이는 허용해야 함");
    }

    private static void includesVideosInSelectedSubfolders() {
        expect(FolderScope.contains("DCIM/", "DCIM/Camera/"),
                "선택 폴더의 하위 폴더 영상도 포함해야 함");
    }

    private static void excludesSiblingFoldersWithSamePrefix() {
        expect(!FolderScope.contains("DCIM/", "DCIM-backup/"),
                "이름 앞부분만 같은 다른 폴더는 포함하면 안 됨");
    }

    private static void expect(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
