package kr.co.salt.videodupecleaner;

import java.util.Arrays;
import java.util.List;

public final class PreviewGroupsTest {
    public static void main(String[] args) {
        groupsMatchingPreviewsWithoutDurationInput();
        excludesMissingAndSinglePreviews();
        System.out.println("PreviewGroupsTest: PASS");
    }

    private static void groupsMatchingPreviewsWithoutDurationInput() {
        PreviewFingerprint same1 = new PreviewFingerprint(1L, 2L, 100, 110, 120);
        PreviewFingerprint different = new PreviewFingerprint(~1L, ~2L, 100, 110, 120);
        PreviewFingerprint same2 = new PreviewFingerprint(1L, 2L, 101, 109, 121);
        List<List<Integer>> groups = PreviewGroups.findGroups(
                Arrays.asList(same1, different, same2));
        expect(groups.size() == 1, "같은 미리보기만 한 묶음으로 만들어야 함");
        expect(groups.get(0).equals(Arrays.asList(0, 2)),
                "미리보기 위치를 원래 영상 순서로 반환해야 함");
    }

    private static void excludesMissingAndSinglePreviews() {
        PreviewFingerprint only = new PreviewFingerprint(1L, 2L, 10, 20, 30);
        List<List<Integer>> groups = PreviewGroups.findGroups(Arrays.asList(null, only));
        expect(groups.isEmpty(), "읽지 못한 화면과 한 개뿐인 화면은 결과에서 제외해야 함");
    }

    private static void expect(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
