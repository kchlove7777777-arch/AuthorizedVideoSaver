package kr.co.salt.videodupecleaner;

public final class PreviewSimilarityTest {
    public static void main(String[] args) {
        createsFingerprintFromDisplayedThumbnailPixels();
        acceptsSamePreviewWhenDurationWouldDiffer();
        acceptsMinorThumbnailEncodingChanges();
        rejectsStructurallyDifferentPreview();
        rejectsSimilarStructureWithDifferentColor();
        rejectsMissingPreview();
        System.out.println("PreviewSimilarityTest: PASS");
    }

    private static void createsFingerprintFromDisplayedThumbnailPixels() {
        int[] redPixels = new int[9 * 8];
        java.util.Arrays.fill(redPixels, 0xFFFF0000);
        PreviewFingerprint fingerprint = PreviewFingerprint.fromNineByEightArgb(redPixels);
        expect(fingerprint != null, "정상 미리보기 픽셀은 지문을 생성해야 함");
        expect(fingerprint.differenceHash == 0L, "단색 화면의 차이 해시는 0이어야 함");
        expect(fingerprint.averageHash == 0L, "단색 화면의 평균 해시는 0이어야 함");
        expect(fingerprint.red == 255 && fingerprint.green == 0 && fingerprint.blue == 0,
                "미리보기의 평균 색상을 계산해야 함");
    }

    private static void acceptsSamePreviewWhenDurationWouldDiffer() {
        PreviewFingerprint first = new PreviewFingerprint(0x0F0F0F0F0F0F0F0FL,
                0x3333333333333333L, 120, 90, 70);
        PreviewFingerprint second = new PreviewFingerprint(0x0F0F0F0F0F0F0F0FL,
                0x3333333333333333L, 120, 90, 70);
        expect(PreviewSimilarity.isSame(first, second),
                "영상 길이와 무관하게 같은 미리보기는 중복이어야 함");
    }

    private static void acceptsMinorThumbnailEncodingChanges() {
        PreviewFingerprint first = new PreviewFingerprint(0x0F0F0F0F0F0F0F0FL,
                0x3333333333333333L, 120, 90, 70);
        PreviewFingerprint second = new PreviewFingerprint(0x0F0F0F0F0F0F0F07L,
                0x3333333333333331L, 126, 87, 73);
        expect(PreviewSimilarity.isSame(first, second),
                "축소·재압축으로 조금 달라진 같은 미리보기는 중복이어야 함");
    }

    private static void rejectsStructurallyDifferentPreview() {
        PreviewFingerprint first = new PreviewFingerprint(0L, 0L, 100, 100, 100);
        PreviewFingerprint second = new PreviewFingerprint(~0L, ~0L, 100, 100, 100);
        expect(!PreviewSimilarity.isSame(first, second),
                "구조가 다른 화면은 중복이면 안 됨");
    }

    private static void rejectsSimilarStructureWithDifferentColor() {
        PreviewFingerprint first = new PreviewFingerprint(1L, 2L, 220, 30, 30);
        PreviewFingerprint second = new PreviewFingerprint(1L, 2L, 30, 30, 220);
        expect(!PreviewSimilarity.isSame(first, second),
                "구조만 같고 색상이 크게 다른 화면은 중복이면 안 됨");
    }

    private static void rejectsMissingPreview() {
        PreviewFingerprint preview = new PreviewFingerprint(1L, 2L, 10, 20, 30);
        expect(!PreviewSimilarity.isSame(preview, null),
                "미리보기를 읽지 못한 영상은 중복이면 안 됨");
    }

    private static void expect(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
