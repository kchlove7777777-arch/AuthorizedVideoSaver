plugins { id("com.android.application") }

android {
    namespace = "kr.co.salt.videodupecleaner"
    compileSdk = 35

    defaultConfig {
        applicationId = "kr.co.salt.videodupecleaner"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
