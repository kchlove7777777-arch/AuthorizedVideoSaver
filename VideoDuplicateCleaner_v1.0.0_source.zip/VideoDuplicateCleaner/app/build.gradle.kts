plugins { id("com.android.application") }

android {
    namespace = "kr.co.salt.videodupecleaner"
    compileSdk = 35

    defaultConfig {
        applicationId = "kr.co.salt.videodupecleaner"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
