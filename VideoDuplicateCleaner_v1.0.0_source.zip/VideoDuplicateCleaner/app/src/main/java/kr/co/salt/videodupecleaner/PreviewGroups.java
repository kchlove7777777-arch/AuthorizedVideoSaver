package kr.co.salt.videodupecleaner;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PreviewGroups {
    private PreviewGroups() {}

    public static List<List<Integer>> findGroups(List<PreviewFingerprint> previews) {
        ArrayList<List<Integer>> result = new ArrayList<>();
        if (previews == null || previews.isEmpty()) return result;

        int[] parent = new int[previews.size()];
        for (int i = 0; i < parent.length; i++) parent[i] = i;
        for (int i = 0; i < previews.size(); i++) {
            PreviewFingerprint first = previews.get(i);
            if (first == null) continue;
            for (int j = i + 1; j < previews.size(); j++) {
                if (PreviewSimilarity.isSame(first, previews.get(j))) union(parent, i, j);
            }
        }

        Map<Integer, List<Integer>> groups = new LinkedHashMap<>();
        for (int i = 0; i < previews.size(); i++) {
            if (previews.get(i) == null) continue;
            groups.computeIfAbsent(find(parent, i), ignored -> new ArrayList<>()).add(i);
        }
        for (List<Integer> group : groups.values()) if (group.size() > 1) result.add(group);
        return result;
    }

    private static int find(int[] parent, int value) {
        while (parent[value] != value) {
            parent[value] = parent[parent[value]];
            value = parent[value];
        }
        return value;
    }

    private static void union(int[] parent, int first, int second) {
        int a = find(parent, first);
        int b = find(parent, second);
        if (a != b) parent[b] = a;
    }
}
