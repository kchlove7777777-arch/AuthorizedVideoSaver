package kr.co.salt.videodupecleaner;

public final class PreviewFingerprint {
    public final long differenceHash;
    public final long averageHash;
    public final int red;
    public final int green;
    public final int blue;

    public PreviewFingerprint(long differenceHash, long averageHash,
                              int red, int green, int blue) {
        this.differenceHash = differenceHash;
        this.averageHash = averageHash;
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public static PreviewFingerprint fromNineByEightArgb(int[] pixels) {
        if (pixels == null || pixels.length != 9 * 8) return null;

        int[] gray = new int[pixels.length];
        long redTotal = 0;
        long greenTotal = 0;
        long blueTotal = 0;
        for (int i = 0; i < pixels.length; i++) {
            int color = pixels[i];
            int red = (color >> 16) & 255;
            int green = (color >> 8) & 255;
            int blue = color & 255;
            redTotal += red;
            greenTotal += green;
            blueTotal += blue;
            gray[i] = (red * 30 + green * 59 + blue * 11) / 100;
        }

        long differenceHash = 0L;
        long grayTotal = 0L;
        int bit = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int index = y * 9 + x;
                if (gray[index] > gray[index + 1]) differenceHash |= 1L << bit;
                grayTotal += gray[index];
                bit++;
            }
        }

        int averageGray = (int) (grayTotal / 64L);
        long averageHash = 0L;
        bit = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                if (gray[y * 9 + x] > averageGray) averageHash |= 1L << bit;
                bit++;
            }
        }

        int count = pixels.length;
        return new PreviewFingerprint(differenceHash, averageHash,
                (int) (redTotal / count), (int) (greenTotal / count),
                (int) (blueTotal / count));
    }
}
