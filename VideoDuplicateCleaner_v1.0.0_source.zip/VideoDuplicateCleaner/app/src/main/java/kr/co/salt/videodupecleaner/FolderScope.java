package kr.co.salt.videodupecleaner;

public final class FolderScope {
    private FolderScope() {}

    public static boolean contains(String selectedRoot, String videoPath) {
        if (selectedRoot == null || selectedRoot.isEmpty()) return true;
        if (videoPath == null) return false;
        String root = selectedRoot.endsWith("/") ? selectedRoot : selectedRoot + "/";
        return videoPath.equals(root) || videoPath.startsWith(root);
    }
}
