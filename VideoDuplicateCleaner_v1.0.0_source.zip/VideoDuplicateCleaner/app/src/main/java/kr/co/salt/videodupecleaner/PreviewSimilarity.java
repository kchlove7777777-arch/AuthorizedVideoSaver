package kr.co.salt.videodupecleaner;

public final class PreviewSimilarity {
    private static final int MAX_DIFFERENCE_DISTANCE = 6;
    private static final int MAX_AVERAGE_DISTANCE = 8;
    private static final int MAX_COLOR_CHANNEL_DISTANCE = 45;
    private static final int MAX_TOTAL_COLOR_DISTANCE = 70;

    private PreviewSimilarity() {}

    public static boolean isSame(PreviewFingerprint first, PreviewFingerprint second) {
        if (first == null || second == null) return false;
        if (Long.bitCount(first.differenceHash ^ second.differenceHash)
                > MAX_DIFFERENCE_DISTANCE) return false;
        if (Long.bitCount(first.averageHash ^ second.averageHash)
                > MAX_AVERAGE_DISTANCE) return false;

        int redDistance = Math.abs(first.red - second.red);
        int greenDistance = Math.abs(first.green - second.green);
        int blueDistance = Math.abs(first.blue - second.blue);
        return redDistance <= MAX_COLOR_CHANNEL_DISTANCE &&
                greenDistance <= MAX_COLOR_CHANNEL_DISTANCE &&
                blueDistance <= MAX_COLOR_CHANNEL_DISTANCE &&
                redDistance + greenDistance + blueDistance <= MAX_TOTAL_COLOR_DISTANCE;
    }
}
