package kr.co.salt.videodupecleaner;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 10, PERMISSION = 11, TRASH = 12;
    private TextView status; private Button scan, trash; private ProgressBar progress;
    private String relativeRoot = ""; private final ArrayList<VideoItem> results = new ArrayList<>();
    private VideoAdapter adapter; private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); scan=findViewById(R.id.scan); trash=findViewById(R.id.trash); progress=findViewById(R.id.progress);
        adapter=new VideoAdapter(); ((ListView)findViewById(R.id.list)).setAdapter(adapter);
        findViewById(R.id.selectFolder).setOnClickListener(v -> chooseFolder());
        scan.setOnClickListener(v -> ensurePermissionAndScan()); trash.setOnClickListener(v -> moveSelectedToTrash());
    }

    private void chooseFolder() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_TREE);
    }

    @Override protected void onActivityResult(int req,int code,Intent data) {
        super.onActivityResult(req,code,data);
        if(req==PICK_TREE && code==RESULT_OK && data!=null){
            Uri u=data.getData(); try { getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
            String id=android.provider.DocumentsContract.getTreeDocumentId(u);
            int colon=id.indexOf(':'); relativeRoot=colon>=0?id.substring(colon+1):"";
            if(!relativeRoot.isEmpty()&&!relativeRoot.endsWith("/")) relativeRoot+="/";
            status.setText("선택 폴더: "+(relativeRoot.isEmpty()?"내부 저장소 전체":relativeRoot)+"\n하위 폴더도 함께 검색합니다."); scan.setEnabled(true);
        } else if(req==TRASH && code==RESULT_OK){ results.removeIf(x->x.checked); adapter.notifyDataSetChanged(); updateSummary(); }
    }

    private void ensurePermissionAndScan(){
        String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_EXTERNAL_STORAGE;
        if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{p},PERMISSION); else startScan();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==PERMISSION&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startScan(); else status.setText("영상 접근 권한이 필요합니다. 설정에서 권한을 허용해 주세요."); }

    private void startScan(){
        scan.setEnabled(false); trash.setEnabled(false); progress.setVisibility(View.VISIBLE); progress.setIndeterminate(true); results.clear(); adapter.notifyDataSetChanged(); status.setText("영상 목록을 확인하는 중…");
        worker.execute(() -> {
            try {
                List<VideoItem> all=queryVideos(); Map<Long,List<VideoItem>> bySize=new HashMap<>();
                for(VideoItem x:all) bySize.computeIfAbsent(x.size,k->new ArrayList<>()).add(x);
                ArrayList<List<VideoItem>> candidates=new ArrayList<>(); for(List<VideoItem> g:bySize.values())if(g.size()>1)candidates.add(g);
                int total=0; for(List<VideoItem> g:candidates)total+=g.size(); final int max=total;
                runOnUiThread(()->{progress.setIndeterminate(false);progress.setMax(Math.max(1,max));progress.setProgress(0);status.setText("같은 크기의 영상 내용을 비교하는 중…");});
                Map<String,List<VideoItem>> hashes=new LinkedHashMap<>(); int done=0;
                for(List<VideoItem> g:candidates)for(VideoItem x:g){ x.hash=sha256(x.uri); hashes.computeIfAbsent(x.hash,k->new ArrayList<>()).add(x); final int d=++done; runOnUiThread(()->progress.setProgress(d)); }
                int group=0; for(List<VideoItem> g:hashes.values())if(g.size()>1){ group++; g.sort(Comparator.comparingLong(x->x.modified)); boolean first=true; for(VideoItem x:g){x.group=group;x.checked=!first;first=false;results.add(x);} }
                runOnUiThread(()->{progress.setVisibility(View.GONE);scan.setEnabled(true);adapter.notifyDataSetChanged();updateSummary();});
            }catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);scan.setEnabled(true);status.setText("검색 중 오류: "+e.getMessage());});}
        });
    }

    private List<VideoItem> queryVideos(){
        ArrayList<VideoItem> out=new ArrayList<>(); Uri base=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] cols={MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.SIZE,MediaStore.Video.Media.DATE_MODIFIED,MediaStore.Video.Media.RELATIVE_PATH};
        try(Cursor c=getContentResolver().query(base,cols,null,null,MediaStore.Video.Media.DATE_MODIFIED+" ASC")){
            if(c!=null)while(c.moveToNext()){ String path=c.getString(4); if(path==null)path=""; if(!relativeRoot.isEmpty()&&!path.startsWith(relativeRoot))continue; long id=c.getLong(0); out.add(new VideoItem(ContentUris.withAppendedId(base,id),c.getString(1),c.getLong(2),c.getLong(3)*1000,path)); }
        } return out;
    }
    private String sha256(Uri uri)throws Exception{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] b=new byte[1024*1024]; try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("파일을 열 수 없음");int n;while((n=in.read(b))>0)md.update(b,0,n);} StringBuilder s=new StringBuilder();for(byte v:md.digest())s.append(String.format(Locale.US,"%02x",v));return s.toString(); }

    private void moveSelectedToTrash(){
        ArrayList<Uri> uris=new ArrayList<>();for(VideoItem x:results)if(x.checked)uris.add(x.uri); if(uris.isEmpty()){Toast.makeText(this,"삭제할 영상을 선택하세요.",Toast.LENGTH_SHORT).show();return;}
        PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),uris,true); try{startIntentSenderForResult(pi.getIntentSender(),TRASH,null,0,0,0);}catch(Exception e){status.setText("휴지통 요청 실패: "+e.getMessage());}
    }
    private void updateSummary(){ int files=results.size(), groups=0,selected=0;long bytes=0;for(VideoItem x:results){groups=Math.max(groups,x.group);if(x.checked){selected++;bytes+=x.size;}} status.setText(groups==0?"완전히 동일한 중복 영상이 없습니다.":groups+"개 중복 묶음 · "+files+"개 파일\n삭제 선택 "+selected+"개 · 확보 가능 "+formatSize(bytes));trash.setEnabled(selected>0); }
    private static String formatSize(long n){if(n>=1073741824)return String.format(Locale.KOREA,"%.2f GB",n/1073741824.0);if(n>=1048576)return String.format(Locale.KOREA,"%.1f MB",n/1048576.0);return n/1024+" KB";}

    class VideoAdapter extends BaseAdapter{
        public int getCount(){return results.size();} public Object getItem(int p){return results.get(p);} public long getItemId(int p){return p;}
        public View getView(int p,View v,android.view.ViewGroup parent){if(v==null)v=getLayoutInflater().inflate(R.layout.item_video,parent,false);VideoItem x=results.get(p);CheckBox c=v.findViewById(R.id.check);ImageView im=v.findViewById(R.id.thumb);TextView n=v.findViewById(R.id.name),m=v.findViewById(R.id.meta);c.setOnCheckedChangeListener(null);c.setChecked(x.checked);c.setOnCheckedChangeListener((b,on)->{x.checked=on;updateSummary();});n.setText("묶음 "+x.group+" · "+x.name+(x.checked?"":"  [유지 추천]"));m.setText(x.path+"\n"+formatSize(x.size)+" · "+DateFormat.getDateTimeInstance().format(new Date(x.modified)));im.setTag(x.uri);im.setImageDrawable(null);worker.execute(()->{try{Bitmap bm=getContentResolver().loadThumbnail(x.uri,new android.util.Size(144,108),null);runOnUiThread(()->{if(x.uri.equals(im.getTag()))im.setImageBitmap(bm);});}catch(Exception ignored){}});return v;}
    }
    static class VideoItem{Uri uri;String name,path,hash;long size,modified;int group;boolean checked;VideoItem(Uri u,String n,long s,long m,String p){uri=u;name=n;size=s;modified=m;path=p;}}
}
