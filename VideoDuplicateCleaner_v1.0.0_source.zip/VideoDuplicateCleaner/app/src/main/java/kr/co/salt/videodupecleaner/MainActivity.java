package kr.co.salt.videodupecleaner;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 10;
    private static final int PERMISSION = 11;
    private static final int TRASH = 12;

    private TextView status;
    private Button scan;
    private Button trash;
    private ProgressBar progress;
    private String relativeRoot = "";
    private String selectedVolume = MediaStore.VOLUME_EXTERNAL_PRIMARY;
    private int totalScanned;
    private int exactGroups;
    private int similarGroups;
    private final Set<Uri> pendingTrashUris = new HashSet<>();
    private final ArrayList<VideoItem> results = new ArrayList<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private VideoAdapter adapter;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        scan = findViewById(R.id.scan);
        trash = findViewById(R.id.trash);
        progress = findViewById(R.id.progress);
        adapter = new VideoAdapter();
        ((ListView) findViewById(R.id.list)).setAdapter(adapter);
        findViewById(R.id.selectFolder).setOnClickListener(v -> chooseFolder());
        scan.setOnClickListener(v -> ensurePermissionAndScan());
        trash.setOnClickListener(v -> moveSelectedToTrash());
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_TREE && result == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}

            String documentId = DocumentsContract.getTreeDocumentId(uri);
            int colon = documentId.indexOf(':');
            String volume = colon >= 0 ? documentId.substring(0, colon) : "primary";
            selectedVolume = "primary".equalsIgnoreCase(volume)
                    ? MediaStore.VOLUME_EXTERNAL_PRIMARY : volume.toLowerCase(Locale.US);
            relativeRoot = colon >= 0 ? documentId.substring(colon + 1) : "";
            if (!relativeRoot.isEmpty() && !relativeRoot.endsWith("/")) relativeRoot += "/";
            status.setText("선택 폴더: " +
                    (relativeRoot.isEmpty() ? "저장소 전체" : relativeRoot) +
                    "\n하위 폴더와 유사 영상도 함께 검색합니다.");
            scan.setEnabled(true);
        } else if (request == TRASH && result == RESULT_OK) {
            results.removeIf(item -> pendingTrashUris.contains(item.uri));
            pendingTrashUris.clear();
            adapter.notifyDataSetChanged();
            updateSummary();
        }
    }

    private void ensurePermissionAndScan() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_VIDEO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{permission}, PERMISSION);
        } else {
            startScan();
        }
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions,
                                                      int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request == PERMISSION && grants.length > 0 &&
                grants[0] == PackageManager.PERMISSION_GRANTED) {
            startScan();
        } else {
            status.setText("모든 동영상에 대한 접근 권한이 필요합니다.\n설정에서 동영상 권한을 허용해 주세요.");
        }
    }

    private void startScan() {
        scan.setEnabled(false);
        trash.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        results.clear();
        adapter.notifyDataSetChanged();
        status.setText("영상 목록을 확인하는 중…");

        worker.execute(() -> {
            try {
                List<VideoItem> all = queryVideos();
                totalScanned = all.size();
                runOnUiThread(() -> status.setText("영상 " + totalScanned +
                        "개 확인 · 완전 중복 후보를 찾는 중…"));

                Map<Long, List<VideoItem>> bySize = new HashMap<>();
                for (VideoItem item : all) {
                    bySize.computeIfAbsent(item.size, ignored -> new ArrayList<>()).add(item);
                }
                ArrayList<VideoItem> exactCandidates = new ArrayList<>();
                for (List<VideoItem> group : bySize.values()) {
                    if (group.size() > 1) exactCandidates.addAll(group);
                }
                int maximum = Math.max(1, exactCandidates.size() + all.size());
                runOnUiThread(() -> {
                    progress.setIndeterminate(false);
                    progress.setMax(maximum);
                    progress.setProgress(0);
                });

                Map<String, List<VideoItem>> hashes = new LinkedHashMap<>();
                int done = 0;
                for (VideoItem item : exactCandidates) {
                    item.hash = sha256(item.uri);
                    hashes.computeIfAbsent(item.hash, ignored -> new ArrayList<>()).add(item);
                    int current = ++done;
                    runOnUiThread(() -> progress.setProgress(current));
                }

                exactGroups = 0;
                for (List<VideoItem> group : hashes.values()) {
                    if (group.size() < 2) continue;
                    exactGroups++;
                    group.sort(Comparator.comparingLong(item -> item.modified));
                    boolean first = true;
                    for (VideoItem item : group) {
                        item.group = exactGroups;
                        item.kind = DuplicateKind.EXACT;
                        item.checked = !first;
                        first = false;
                        results.add(item);
                    }
                }

                runOnUiThread(() -> status.setText("영상 " + totalScanned +
                        "개 확인 · 장면을 비교하는 중…"));
                ArrayList<VideoItem> visualCandidates = uniqueContentRepresentatives(all);
                for (VideoItem item : visualCandidates) {
                    item.frameHashes = createFrameHashes(item);
                    int current = ++done;
                    runOnUiThread(() -> progress.setProgress(current));
                }

                List<List<VideoItem>> similar = groupSimilarVideos(visualCandidates);
                similarGroups = 0;
                for (List<VideoItem> group : similar) {
                    similarGroups++;
                    group.sort(Comparator.comparingLong(item -> item.modified));
                    for (VideoItem item : group) {
                        VideoItem display = item.copyForResult();
                        display.group = similarGroups;
                        display.kind = DuplicateKind.SIMILAR;
                        display.checked = false;
                        results.add(display);
                    }
                }

                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    scan.setEnabled(true);
                    adapter.notifyDataSetChanged();
                    updateSummary();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    scan.setEnabled(true);
                    status.setText("검색 중 오류: " + error.getMessage());
                });
            }
        });
    }

    private List<VideoItem> queryVideos() {
        ArrayList<VideoItem> items = new ArrayList<>();
        Set<String> available = MediaStore.getExternalVolumeNames(this);
        if (!available.contains(selectedVolume)) return items;
        Uri base = MediaStore.Video.Media.getContentUri(selectedVolume);
        String[] columns = {MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED,
                MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DURATION};
        try (Cursor cursor = getContentResolver().query(base, columns, null, null,
                MediaStore.Video.Media.DATE_MODIFIED + " ASC")) {
            if (cursor == null) return items;
            while (cursor.moveToNext()) {
                String path = cursor.getString(4);
                if (!FolderScope.contains(relativeRoot, path)) continue;
                long id = cursor.getLong(0);
                items.add(new VideoItem(ContentUris.withAppendedId(base, id), cursor.getString(1),
                        cursor.getLong(2), cursor.getLong(3) * 1000,
                        path == null ? "" : path, cursor.getLong(5)));
            }
        }
        return items;
    }

    private ArrayList<VideoItem> uniqueContentRepresentatives(List<VideoItem> all) {
        ArrayList<VideoItem> unique = new ArrayList<>();
        Set<String> seenHashes = new HashSet<>();
        for (VideoItem item : all) {
            if (item.hash == null || seenHashes.add(item.hash)) unique.add(item);
        }
        return unique;
    }

    private List<List<VideoItem>> groupSimilarVideos(List<VideoItem> items) {
        int[] parent = new int[items.size()];
        for (int i = 0; i < parent.length; i++) parent[i] = i;
        for (int i = 0; i < items.size(); i++) {
            VideoItem first = items.get(i);
            if (first.frameHashes == null) continue;
            for (int j = i + 1; j < items.size(); j++) {
                VideoItem second = items.get(j);
                if (second.frameHashes == null) continue;
                if (VideoSimilarity.isSimilar(first.durationMs, first.frameHashes,
                        second.durationMs, second.frameHashes)) union(parent, i, j);
            }
        }
        Map<Integer, List<VideoItem>> groups = new LinkedHashMap<>();
        for (int i = 0; i < items.size(); i++) {
            groups.computeIfAbsent(find(parent, i), ignored -> new ArrayList<>()).add(items.get(i));
        }
        ArrayList<List<VideoItem>> result = new ArrayList<>();
        for (List<VideoItem> group : groups.values()) if (group.size() > 1) result.add(group);
        return result;
    }

    private static int find(int[] parent, int value) {
        while (parent[value] != value) {
            parent[value] = parent[parent[value]];
            value = parent[value];
        }
        return value;
    }

    private static void union(int[] parent, int first, int second) {
        int a = find(parent, first);
        int b = find(parent, second);
        if (a != b) parent[b] = a;
    }

    private long[] createFrameHashes(VideoItem item) {
        if (item.durationMs <= 0) return null;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, item.uri);
            long[] hashes = new long[3];
            double[] points = {0.20, 0.50, 0.80};
            for (int i = 0; i < points.length; i++) {
                long timeUs = Math.round(item.durationMs * 1000.0 * points[i]);
                Bitmap frame = retriever.getFrameAtTime(timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST);
                if (frame == null) return null;
                hashes[i] = differenceHash(frame);
                frame.recycle();
            }
            return hashes;
        } catch (Exception ignored) {
            return null;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private static long differenceHash(Bitmap source) {
        Bitmap small = Bitmap.createScaledBitmap(source, 9, 8, true);
        long hash = 0L;
        int bit = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int left = small.getPixel(x, y);
                int right = small.getPixel(x + 1, y);
                int leftGray = (((left >> 16) & 255) * 30 + ((left >> 8) & 255) * 59 +
                        (left & 255) * 11) / 100;
                int rightGray = (((right >> 16) & 255) * 30 + ((right >> 8) & 255) * 59 +
                        (right & 255) * 11) / 100;
                if (leftGray > rightGray) hash |= (1L << bit);
                bit++;
            }
        }
        if (small != source) small.recycle();
        return hash;
    }

    private String sha256(Uri uri) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("파일을 열 수 없음");
            int count;
            while ((count = input.read(buffer)) > 0) digest.update(buffer, 0, count);
        }
        StringBuilder value = new StringBuilder();
        for (byte part : digest.digest()) value.append(String.format(Locale.US, "%02x", part));
        return value.toString();
    }

    private void moveSelectedToTrash() {
        ArrayList<Uri> uris = new ArrayList<>();
        for (VideoItem item : results) if (item.checked && !uris.contains(item.uri)) uris.add(item.uri);
        if (uris.isEmpty()) {
            Toast.makeText(this, "삭제할 영상을 선택하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        pendingTrashUris.clear();
        pendingTrashUris.addAll(uris);
        PendingIntent request = MediaStore.createTrashRequest(getContentResolver(), uris, true);
        try {
            startIntentSenderForResult(request.getIntentSender(), TRASH, null, 0, 0, 0);
        } catch (Exception error) {
            status.setText("휴지통 요청 실패: " + error.getMessage());
        }
    }

    private void updateSummary() {
        int selected = 0;
        long bytes = 0;
        Set<Uri> selectedUris = new HashSet<>();
        for (VideoItem item : results) {
            if (item.checked && selectedUris.add(item.uri)) {
                selected++;
                bytes += item.size;
            }
        }
        if (exactGroups == 0 && similarGroups == 0) {
            status.setText("검색 영상 " + totalScanned + "개\n중복 또는 유사 영상이 없습니다.");
        } else {
            status.setText("검색 영상 " + totalScanned + "개 · 완전 중복 " + exactGroups +
                    "묶음 · 유사 중복 " + similarGroups + "묶음\n삭제 선택 " + selected +
                    "개 · 확보 가능 " + formatSize(bytes));
        }
        trash.setEnabled(selected > 0);
    }

    private static String formatSize(long bytes) {
        if (bytes >= 1073741824) return String.format(Locale.KOREA, "%.2f GB", bytes / 1073741824.0);
        if (bytes >= 1048576) return String.format(Locale.KOREA, "%.1f MB", bytes / 1048576.0);
        return bytes / 1024 + " KB";
    }

    private enum DuplicateKind { EXACT, SIMILAR }

    private final class VideoAdapter extends BaseAdapter {
        @Override public int getCount() { return results.size(); }
        @Override public Object getItem(int position) { return results.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View view, ViewGroup parent) {
            if (view == null) view = getLayoutInflater().inflate(R.layout.item_video, parent, false);
            VideoItem item = results.get(position);
            CheckBox check = view.findViewById(R.id.check);
            ImageView image = view.findViewById(R.id.thumb);
            TextView name = view.findViewById(R.id.name);
            TextView meta = view.findViewById(R.id.meta);
            check.setOnCheckedChangeListener(null);
            check.setChecked(item.checked);
            check.setOnCheckedChangeListener((button, checked) -> {
                item.checked = checked;
                updateSummary();
            });
            String kind = item.kind == DuplicateKind.EXACT ? "완전 중복" : "유사 중복";
            String advice = item.kind == DuplicateKind.EXACT && !item.checked
                    ? " [유지 추천]" : item.kind == DuplicateKind.SIMILAR ? " [직접 확인]" : "";
            name.setText(kind + " " + item.group + " · " + item.name + advice);
            meta.setText(item.path + "\n" + formatSize(item.size) + " · " +
                    DateFormat.getDateTimeInstance().format(new Date(item.modified)));
            image.setTag(item.uri);
            image.setImageDrawable(null);
            worker.execute(() -> {
                try {
                    Bitmap thumbnail = getContentResolver().loadThumbnail(item.uri,
                            new Size(144, 108), null);
                    runOnUiThread(() -> {
                        if (item.uri.equals(image.getTag())) image.setImageBitmap(thumbnail);
                    });
                } catch (Exception ignored) {}
            });
            return view;
        }
    }

    private static final class VideoItem {
        final Uri uri;
        final String name;
        final long size;
        final long modified;
        final String path;
        final long durationMs;
        String hash;
        long[] frameHashes;
        int group;
        DuplicateKind kind;
        boolean checked;

        VideoItem(Uri uri, String name, long size, long modified, String path, long durationMs) {
            this.uri = uri;
            this.name = name;
            this.size = size;
            this.modified = modified;
            this.path = path;
            this.durationMs = durationMs;
        }

        VideoItem copyForResult() {
            return new VideoItem(uri, name, size, modified, path, durationMs);
        }
    }
}
