package kr.co.salt.videodupecleaner;

public final class VideoSimilarity {
    private static final int MAX_FRAME_DISTANCE = 12;
    private static final int MAX_TOTAL_DISTANCE = 24;

    private VideoSimilarity() {}

    public static boolean isSimilar(long firstDurationMs, long[] firstFrames,
                                    long secondDurationMs, long[] secondFrames) {
        if (firstDurationMs <= 0 || secondDurationMs <= 0 ||
                firstFrames == null || secondFrames == null ||
                firstFrames.length != 3 || secondFrames.length != 3) return false;

        long durationTolerance = Math.max(1_000L,
                Math.round(Math.min(firstDurationMs, secondDurationMs) * 0.02));
        if (Math.abs(firstDurationMs - secondDurationMs) > durationTolerance) return false;

        int totalDistance = 0;
        for (int i = 0; i < 3; i++) {
            int distance = Long.bitCount(firstFrames[i] ^ secondFrames[i]);
            if (distance > MAX_FRAME_DISTANCE) return false;
            totalDistance += distance;
        }
        return totalDistance <= MAX_TOTAL_DISTANCE;
    }
}
